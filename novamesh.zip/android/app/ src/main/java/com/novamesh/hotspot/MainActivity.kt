package com.novamesh.hotspot

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * NovaMesh MainActivity
 *
 * Entry point of the app. Handles:
 *  1. Firebase sign-in
 *  2. Starting the HotspotService (foreground service)
 *  3. Showing the local web dashboard URL to the user
 *  4. Basic status display
 *
 * The main "UI" is the web dashboard served at 192.168.43.1:8080.
 * This activity is minimal — just a launcher/control panel.
 *
 * Layout file: activity_main.xml (see companion layout below)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var configStore: HotspotConfigStore
    private lateinit var firebaseManager: FirebaseManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configStore     = HotspotConfigStore(this)
        firebaseManager = FirebaseManager(this)

        // Check if already signed in
        if (firebaseManager.isSignedIn()) {
            onSignedIn()
        } else {
            startSignIn()
        }
    }

    // ────────────────────────────────────────────
    //  Auth Flow
    // ────────────────────────────────────────────

    private fun startSignIn() {
        // In production: show login UI (EditText for email/password)
        // Demo: sign in with hardcoded credentials for testing
        firebaseManager.signIn(
            email    = "admin@novamesh.local",
            password = "nova2024",
            onSuccess = { user ->
                Toast.makeText(this, "Signed in: ${user.email}", Toast.LENGTH_SHORT).show()
                onSignedIn()
            },
            onError = { e ->
                // If Firebase auth fails, continue in local-only mode
                Toast.makeText(this, "Firebase offline — local mode", Toast.LENGTH_SHORT).show()
                startHotspotService()
            }
        )
    }

    private fun onSignedIn() {
        // Start the hotspot service
        startHotspotService()

        // Get admin token for web UI authentication
        lifecycleScope.launch(Dispatchers.IO) {
            val config = configStore.getConfig()
            withContext(Dispatchers.Main) {
                showDashboardInfo(config)
            }
        }
    }

    // ────────────────────────────────────────────
    //  Service Control
    // ────────────────────────────────────────────

    private fun startHotspotService() {
        val intent = HotspotService.startIntent(this)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopHotspotService() {
        startService(HotspotService.stopIntent(this))
    }

    // ────────────────────────────────────────────
    //  UI Display
    // ────────────────────────────────────────────

    private fun showDashboardInfo(config: HotspotConfig) {
        val dashboardUrl = "http://${HotspotManager.HOTSPOT_IP}:8080"
        val tokenDisplay = config.adminToken.take(8) + "..."

        // Update UI TextViews (bind your layout IDs here)
        // tvDashboardUrl.text = dashboardUrl
        // tvSSID.text = config.ssid
        // tvToken.text = tokenDisplay
        // tvStatus.text = "Service running"

        Toast.makeText(this,
            "Dashboard: $dashboardUrl\nSSID: ${config.ssid}",
            Toast.LENGTH_LONG
        ).show()
    }

    /**
     * Opens the dashboard in the device's browser.
     * Users connect via hotspot, then browse to this address.
     */
    fun openDashboard() {
        val url = "http://${HotspotManager.HOTSPOT_IP}:8080"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    override fun onDestroy() {
        super.onDestroy()
        // Note: HotspotService continues running after activity is destroyed
    }
}

/*
 * ═══════════════════════════════════════════════
 *  activity_main.xml  (res/layout/activity_main.xml)
 * ═══════════════════════════════════════════════
 *
 * <?xml version="1.0" encoding="utf-8"?>
 * <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
 *     android:layout_width="match_parent"
 *     android:layout_height="match_parent"
 *     android:orientation="vertical"
 *     android:padding="24dp"
 *     android:background="#03080f">
 *
 *     <TextView android:id="@+id/tvTitle"
 *         android:text="NovaMesh"
 *         android:textSize="28sp"
 *         android:textColor="#00c8ff"
 *         android:textStyle="bold"
 *         android:layout_width="wrap_content"
 *         android:layout_height="wrap_content"
 *         android:layout_marginBottom="8dp"/>
 *
 *     <TextView android:id="@+id/tvStatus"
 *         android:text="Service starting..."
 *         android:textColor="#6b8ca8"
 *         android:layout_width="wrap_content"
 *         android:layout_height="wrap_content"
 *         android:layout_marginBottom="32dp"/>
 *
 *     <TextView android:id="@+id/tvSSID"
 *         android:text="SSID: —"
 *         android:textColor="#d0e8f8"
 *         android:layout_width="wrap_content"
 *         android:layout_height="wrap_content"/>
 *
 *     <TextView android:id="@+id/tvDashboardUrl"
 *         android:text="Dashboard: —"
 *         android:textColor="#00c8ff"
 *         android:layout_width="wrap_content"
 *         android:layout_height="wrap_content"
 *         android:layout_marginTop="8dp"/>
 *
 *     <Button android:id="@+id/btnOpenDashboard"
 *         android:text="Open Dashboard"
 *         android:layout_width="match_parent"
 *         android:layout_height="wrap_content"
 *         android:layout_marginTop="32dp"
 *         android:onClick="openDashboard"/>
 *
 *     <Button android:id="@+id/btnStop"
 *         android:text="Stop Service"
 *         android:layout_width="match_parent"
 *         android:layout_height="wrap_content"
 *         android:layout_marginTop="12dp"/>
 * </LinearLayout>
 */
